import './wavesurfer-setup.js';
import './canvas-draw.js';
import './interaction.js';
import './controls.js';
import './send-payload.js';
